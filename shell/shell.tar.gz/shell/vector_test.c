/**
 * Machine Problem: Shell
 * CS 241 - Spring 2016
 */
#include "vector.h"
// Create and test your vector here
int main() { return 0; }
