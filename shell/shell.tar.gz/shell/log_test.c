/**
 * Machine Problem: Shell
 * CS 241 - Spring 2016
 */
#include "log.h"
// Create and test your log here
int main() { return 0; }
