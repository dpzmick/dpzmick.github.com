/**
 * Machine Problem: Shell
 * CS 241 - Spring 2016
 */
/* An automatically-expanding array of Vector. */
#include "vector.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>

#define INITIAL_CAPACITY 10

/* Allocate and return a new Vector structure. */
Vector *Vector_create() {
  Vector *s = (Vector *)malloc(sizeof(Vector));
  assert(s);
  s->size = 0;
  s->capacity = INITIAL_CAPACITY;

  s->array = (char **)calloc(s->capacity, sizeof(char **));
  assert(s->array);

  return s;
}

/* Deallocate a Vector structure.
   Every non-NULL entry in array from array[0] to array[size-1] will
   need to be free()d.
*/
void Vector_destroy(Vector *s) {
  assert(s);

  // this deallocates the entire Vector
  Vector_resize(s, 0);

  // now deallocate the array
  free(s->array);

  // and the structure
  free(s);
}

/* Return the number of entries in use in this array. */
int Vector_size(Vector *s) {
  assert(s);
  return s->size;
}

/* Sets the number of entries in use in this array.

   If the array grows, new entries will be initialized to NULL.
   Also, when growing the array, grow by at least some constant factor.
   Either 2 or 3/2 are recommended. In other words,
   if new_size > capacity:
     new_capacity = maximum(capacity * 2, new_size);

   If the array shrinks, entries past the new end of the array
   will be deallocated. */
void Vector_resize(Vector *s, size_t new_size) {
  assert(s);
  assert(s->size <= s->capacity);
  assert(new_size >= 0);

  // if we're growing
  if (new_size > s->size) {

    // check if we need to reallocate
    if (new_size > s->capacity) {

      size_t new_capacity = s->capacity * 2;
      assert(new_capacity > s->capacity);

      if (new_capacity < new_size) {
        new_capacity = new_size;
      }

      s->array = (char **)realloc(s->array, new_capacity * sizeof(char *));
      s->capacity = new_capacity;
    }

    // initialize the new entries
    memset(s->array + s->size, 0, sizeof(char *) * (new_size - s->size));
  }

  // if we're shrinking, deallocate the entries past the end, but don't
  // actually change the capacity.
  else if (new_size < s->size) {
    for (size_t i = new_size; i < s->size; i++) {
      Vector_set(s, i, NULL);
    }
  }

  s->size = new_size;
}

/* Allocate a copy of 'str' and store it in array[index].
   If 'str' is NULL, just store NULL in array[index]. */
void Vector_set(Vector *s, size_t index, const char *str) {
  assert(s);
  assert(index >= 0 && index < s->size);

  // if given a null string, deallocate what's currently stored,
  // if anything.
  if (str == NULL) {
    if (s->array[index]) {
      free(s->array[index]);
    }
    s->array[index] = NULL;
    return;
  }

  size_t new_len = strlen(str);

  // allocate space for the new string
  if (s->array[index] == NULL) {
    s->array[index] = (char *)malloc(new_len + 1);
  } else {
    s->array[index] = (char *)realloc(s->array[index], new_len + 1);
  }

  strcpy(s->array[index], str);
}

/* Returns the string stored at array[index].
   If array[index]==NULL, this will return NULL.

   This does not return a copy of the string; it returns the actual
   char* stored at array[index]. This means the caller must not
   deallocate the string.
*/
const char *Vector_get(Vector *s, size_t index) {
  assert(s);
  assert(index >= 0 && index < s->size);
  return s->array[index];
}

/* Apppends a copy of 'str', or NULL if str is NULL
   to the end of the array. */
void Vector_append(Vector *s, const char *str) {
  size_t current_size = Vector_size(s);
  Vector_resize(s, current_size + 1);
  Vector_set(s, current_size, str);
}
