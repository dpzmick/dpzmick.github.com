/**
 * Machine Problem: Shell
 * CS 241 - Spring 2016
 */
/** @file shell.c */
#include "log.h"

/**
 * Starting point for shell.
 */
int main(int argc, char **argv) { return 0; }
