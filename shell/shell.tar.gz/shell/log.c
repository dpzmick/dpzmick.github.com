/**
 * Machine Problem: Shell
 * CS 241 - Spring 2016
 */
/** @file log.c */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include "log.h"
#include "vector.h"

Log *Log_create(const char *filename) {
  Log *log = (Log *)malloc(sizeof(Log));
  log->vtr = Vector_create();

  if (filename == NULL) {
    return log;
  }

  FILE *inf = fopen(filename, "r");
  if (inf == NULL) {
    return log;
  }

  char *line = NULL;
  size_t line_len = 0;

  while (1) {
    ssize_t bytes_read = getline(&line, &line_len, inf);
    if (bytes_read < 0) {
      break;
    }
    line[bytes_read - 1] = '\0';
    Vector_append(log->vtr, line);
  }

  if (line)
    free(line);
  fclose(inf);
  return log;
}

int Log_save(Log *log, const char *filename) {
  FILE *file = fopen(filename, "w+");
  if (file == NULL) {
    return 1;
  }
  for (size_t i = 0; i < log->vtr->size; i++) {
    fputs(Log_get_command(log, i), file);
    fputc('\n', file);
  }
  if (file != NULL)
    fclose(file);
  return 0;
}

void Log_destroy(Log *log) {
  Vector_destroy(log->vtr);
  free(log);
}

void Log_add_command(Log *log, const char *command) {
  Vector_append(log->vtr, command);
}

const char *Log_reverse_search(Log *log, const char *prefix) {
  if (prefix == NULL)
    return NULL;

  for (size_t i = 0; i < log->vtr->size; i++) {
    size_t idx = log->vtr->size - 1 - i;
    if (strncmp(log->vtr->array[idx], prefix, strlen(prefix)) == 0)
      return Vector_get(log->vtr, idx);
  }
  return NULL;
}

const char *Log_get_command(Log *log, size_t index) {
  if ((int)index >= (Vector_size(log->vtr))) {
    return NULL;
  } else {
    return Vector_get(log->vtr, index);
  }

  // return log->vtr->array[index];
}

char *Log_get_printable_history(Log *log) {
  // Stolen from sqiou2
  char *result = NULL;
  char *formatted_cmd = NULL;

  for (size_t i = 0; i < (size_t)Vector_size(log->vtr); i++) {
    size_t len = strlen(Vector_get(log->vtr, i)) + 10 + 2;
    formatted_cmd = (char *)malloc(len);
    memset(formatted_cmd, 0, len);
    sprintf(formatted_cmd, "%zu\t%s\n", i, Vector_get(log->vtr, i));

    if (result != NULL) {
      result = (char *)realloc(result, strlen(result) + len + 1);
      memset(result + strlen(result), 0, len + 1);
      strcat(result, formatted_cmd);
    } else {
      result = (char *)malloc(len + 1);
      memset(result, 0, len + 1);
      strcpy(result, formatted_cmd);
    }
    free(formatted_cmd);
    formatted_cmd = NULL;
  }
  return result;
}
